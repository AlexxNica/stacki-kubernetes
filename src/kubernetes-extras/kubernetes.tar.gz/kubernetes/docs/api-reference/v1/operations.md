<!-- needed for gh-pages to render html files when imported -->
{% include <REPLACE-WITH-RELEASE-VERSION>/v1-operations.html %}




<!-- BEGIN MUNGE: GENERATED_ANALYTICS -->
[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/docs/api-reference/v1/operations.md?pixel)]()
<!-- END MUNGE: GENERATED_ANALYTICS -->
