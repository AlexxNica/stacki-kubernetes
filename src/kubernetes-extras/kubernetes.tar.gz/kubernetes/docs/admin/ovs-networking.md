This file has moved to: http://kubernetes.github.io/docs/admin/ovs-networking/


<!-- BEGIN MUNGE: GENERATED_ANALYTICS -->
[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/docs/admin/ovs-networking.md?pixel)]()
<!-- END MUNGE: GENERATED_ANALYTICS -->
